using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>
/// Đầu mối quản lý Music, SFX và âm lượng toàn game.
/// Đặt VolumeManager trong scene khởi động, gán AudioConfig trong Inspector,
/// sau đó object sẽ tự tồn tại qua các scene.
/// </summary>
public sealed class VolumeManager : MonoBehaviour
{
    private const string MasterKey = "Audio.MasterVolume";
    private const string MusicKey = "Audio.MusicVolume";
    private const string SfxKey = "Audio.SFXVolume";
    private const string MasterMuteKey = "Audio.MasterMuted";
    private const string MusicMuteKey = "Audio.MusicMuted";
    private const string SfxMuteKey = "Audio.SFXMuted";

    private static VolumeManager instance;
    private static readonly HashSet<AudioSource> legacyMusicSources = new HashSet<AudioSource>();
    private static readonly HashSet<AudioSource> legacySfxSources = new HashSet<AudioSource>();

    [Header("Audio database")]
    [SerializeField] private AudioConfig audioConfig;

    [Header("Optional startup music")]
    [SerializeField] private bool playStartupMusic;
    [SerializeField, RegistryId(RegistryIdType.Music)] private string startupMusicId;

    [Header("Footsteps")]
    [Tooltip("ID SFX mặc định được gán cho Player nếu Player chưa có FootstepAudioPlayer cấu hình sẵn.")]
    [SerializeField, RegistryId(RegistryIdType.Sfx)] private string defaultFootstepSfxId;

    [Header("Default volume")]
    [Range(0f, 1f)] [SerializeField] private float defaultMaster = 1f;
    [Range(0f, 1f)] [SerializeField] private float defaultMusic = 0.8f;
    [Range(0f, 1f)] [SerializeField] private float defaultSfx = 1f;

    private float masterVolume;
    private float musicVolume;
    private float sfxVolume;
    private bool masterMuted;
    private bool musicMuted;
    private bool sfxMuted;

    private AudioSource musicSource;
    private readonly List<AudioSource> oneShotPool = new List<AudioSource>();
    private readonly Dictionary<string, AudioSource> activeSfxLoops = new Dictionary<string, AudioSource>(StringComparer.Ordinal);
    private readonly Dictionary<string, float> sfxLoopEndTimes = new Dictionary<string, float>(StringComparer.Ordinal);
    private readonly List<string> expiredLoopIds = new List<string>();
    private readonly HashSet<string> missingMusicWarnings = new HashSet<string>();
    private readonly HashSet<string> missingSfxWarnings = new HashSet<string>();

    private string currentMusicId;
    private float musicEndTime;

    public static event Action OnAudioSettingsChanged;

    public static float MasterVolume => instance != null ? instance.masterVolume : 1f;
    public static float MusicVolume => instance != null ? instance.musicVolume : 0.8f;
    public static float SFXVolume => instance != null ? instance.sfxVolume : 1f;
    public static bool MasterMuted => instance != null && instance.masterMuted;
    public static bool MusicMuted => instance != null && instance.musicMuted;
    public static bool SFXMuted => instance != null && instance.sfxMuted;
    public static bool IsReady => instance != null;
    public static string CurrentMusicId => instance != null ? instance.currentMusicId : null;

    private void Awake()
    {
        if (instance != null && instance != this)
        {
            Destroy(gameObject);
            return;
        }

        instance = this;
        if (transform.parent != null) transform.SetParent(null);
        DontDestroyOnLoad(gameObject);

        LoadSettings();
        CreateMusicSource();

        if (audioConfig == null)
            Debug.LogError("[VolumeManager] Chưa gán AudioConfig trong Inspector.", this);
        else
            audioConfig.RebuildLookup();

        SceneManager.sceneLoaded += OnSceneLoaded;
        ApplyVolumes();
    }

    private void Start()
    {
        AttachFootstepPlayers(SceneManager.GetActiveScene());

        if (playStartupMusic && !string.IsNullOrWhiteSpace(startupMusicId))
            ToggleMusicInternal(startupMusicId, true);
    }

    private void Update()
    {
        UpdateMusicLifetime();
        UpdateSfxLoopLifetimes();
    }

    private void OnDestroy()
    {
        if (instance != this) return;

        SceneManager.sceneLoaded -= OnSceneLoaded;
        instance = null;
        legacyMusicSources.Clear();
        legacySfxSources.Clear();
        OnAudioSettingsChanged = null;
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode) => AttachFootstepPlayers(scene);

    private void AttachFootstepPlayers(Scene scene)
    {
        if (!scene.IsValid() || !scene.isLoaded) return;

        foreach (GameObject playerObject in GameObject.FindGameObjectsWithTag("Player"))
        {
            FootstepAudioPlayer footstep = playerObject.GetComponent<FootstepAudioPlayer>();
            if (footstep == null)
                footstep = playerObject.AddComponent<FootstepAudioPlayer>();

            if (!string.IsNullOrWhiteSpace(defaultFootstepSfxId))
                footstep.SetSfxId(defaultFootstepSfxId);
        }
    }

    private void LoadSettings()
    {
        masterVolume = Mathf.Clamp01(PlayerPrefs.GetFloat(MasterKey, defaultMaster));
        musicVolume = Mathf.Clamp01(PlayerPrefs.GetFloat(MusicKey, defaultMusic));
        sfxVolume = Mathf.Clamp01(PlayerPrefs.GetFloat(SfxKey, defaultSfx));
        masterMuted = PlayerPrefs.GetInt(MasterMuteKey, 0) == 1;
        musicMuted = PlayerPrefs.GetInt(MusicMuteKey, 0) == 1;
        sfxMuted = PlayerPrefs.GetInt(SfxMuteKey, 0) == 1;
    }

    private void CreateMusicSource()
    {
        musicSource = gameObject.AddComponent<AudioSource>();
        musicSource.playOnAwake = false;
        musicSource.loop = true;
        musicSource.spatialBlend = 0f;
        musicSource.volume = 0f;
    }

    private void OnApplicationPause(bool paused)
    {
        if (paused) PlayerPrefs.Save();
    }

    private void OnApplicationQuit() => PlayerPrefs.Save();

    // -------------------------------------------------------------------------
    // Public audio API: các nơi khác trong game chỉ cần gọi bằng ID.
    // -------------------------------------------------------------------------

    /// <summary>
    /// Bật một bài nhạc. Nếu ID khác bài hiện tại thì tự đổi bài.
    /// Tắt bài nhạc chỉ khi ID truyền vào đúng là bài đang phát.
    /// </summary>
    public static void ToggleMusic(string musicId, bool onOrOff)
    {
        if (instance == null)
        {
            Debug.LogWarning("[VolumeManager] Không tìm thấy VolumeManager trong scene khởi động.");
            return;
        }
        instance.ToggleMusicInternal(musicId, onOrOff);
    }

    /// <summary>Phát SFX một lần.</summary>
    public static void PlaySFX(string sfxId)
    {
        if (instance == null)
        {
            Debug.LogWarning("[VolumeManager] Không tìm thấy VolumeManager trong scene khởi động.");
            return;
        }
        instance.PlaySfxInternal(sfxId);
    }

    /// <summary>
    /// Phát SFX lặp. durationSeconds <= 0: lặp vô hạn đến khi gọi StopSFXLoop.
    /// durationSeconds > 0: tự dừng sau số giây được chỉ định.
    /// </summary>
    public static void PlaySFXLoop(string sfxId, float durationSeconds = 0f)
    {
        if (instance == null)
        {
            Debug.LogWarning("[VolumeManager] Không tìm thấy VolumeManager trong scene khởi động.");
            return;
        }
        instance.PlaySfxLoopInternal(sfxId, durationSeconds);
    }

    /// <summary>Dừng SFX loop theo ID. Không ảnh hưởng đến các lần phát một lần.</summary>
    public static void StopSFXLoop(string sfxId)
    {
        if (instance == null) return;
        instance.StopSfxLoopInternal(sfxId);
    }

    // -------------------------------------------------------------------------
    // Volume settings API - giữ tương thích với VolumeSettingsUI hiện tại.
    // -------------------------------------------------------------------------

    // Compatibility cho các AudioSource cũ chưa chuyển sang AudioConfig.
    // Code mới nên dùng PlaySFX/PlaySFXLoop/ToggleMusic bằng ID.
    public static void RegisterMusicSource(AudioSource source) => RegisterLegacySource(source, legacyMusicSources, true);
    public static void UnregisterMusicSource(AudioSource source) => legacyMusicSources.Remove(source);
    public static void RegisterSFXSource(AudioSource source) => RegisterLegacySource(source, legacySfxSources, false);
    public static void UnregisterSFXSource(AudioSource source) => legacySfxSources.Remove(source);

    private static void RegisterLegacySource(AudioSource source, HashSet<AudioSource> sources, bool isMusic)
    {
        if (source == null) return;
        sources.Add(source);
        if (instance != null)
            source.volume = isMusic ? instance.GetMusicChannelVolume() : instance.GetSfxChannelVolume();
    }

    public static void SetMasterVolume(float value) => SetLevel(value, 0);
    public static void SetMusicVolume(float value) => SetLevel(value, 1);
    public static void SetSFXVolume(float value) => SetLevel(value, 2);
    public static void SetMasterMuted(bool value) => SetMute(value, 0);
    public static void SetMusicMuted(bool value) => SetMute(value, 1);
    public static void SetSFXMuted(bool value) => SetMute(value, 2);

    private static void SetLevel(float value, int channel)
    {
        if (instance == null) return;
        value = Mathf.Clamp01(value);

        switch (channel)
        {
            case 0:
                instance.masterVolume = value;
                PlayerPrefs.SetFloat(MasterKey, value);
                break;
            case 1:
                instance.musicVolume = value;
                PlayerPrefs.SetFloat(MusicKey, value);
                break;
            default:
                instance.sfxVolume = value;
                PlayerPrefs.SetFloat(SfxKey, value);
                break;
        }

        instance.ApplyVolumes();
        OnAudioSettingsChanged?.Invoke();
    }

    private static void SetMute(bool value, int channel)
    {
        if (instance == null) return;

        switch (channel)
        {
            case 0:
                instance.masterMuted = value;
                PlayerPrefs.SetInt(MasterMuteKey, value ? 1 : 0);
                break;
            case 1:
                instance.musicMuted = value;
                PlayerPrefs.SetInt(MusicMuteKey, value ? 1 : 0);
                break;
            default:
                instance.sfxMuted = value;
                PlayerPrefs.SetInt(SfxMuteKey, value ? 1 : 0);
                break;
        }

        instance.ApplyVolumes();
        OnAudioSettingsChanged?.Invoke();
    }

    // -------------------------------------------------------------------------
    // Internal music
    // -------------------------------------------------------------------------

    private void ToggleMusicInternal(string musicId, bool onOrOff)
    {
        if (string.IsNullOrWhiteSpace(musicId)) return;

        if (!onOrOff)
        {
            if (string.Equals(currentMusicId, musicId, StringComparison.Ordinal))
                StopCurrentMusic();
            return;
        }

        if (audioConfig == null || !audioConfig.TryGetMusic(musicId, out AudioConfig.MusicEntry entry))
        {
            WarnMissingId(musicId, true);
            return;
        }

        if (entry.clip == null)
        {
            Debug.LogWarning($"[VolumeManager] Music '{musicId}' chưa được gán AudioClip.", this);
            return;
        }

        if (currentMusicId == musicId && musicSource.isPlaying) return;

        StopCurrentMusic();
        currentMusicId = musicId;
        musicSource.clip = entry.clip;
        musicSource.loop = entry.loop;
        musicSource.pitch = Mathf.Max(0.1f, entry.pitch);
        musicSource.volume = GetMusicChannelVolume() * Mathf.Clamp01(entry.volume);
        musicSource.Play();

        musicEndTime = entry.stopAfterSeconds > 0f
            ? Time.unscaledTime + entry.stopAfterSeconds
            : 0f;
    }

    private void StopCurrentMusic()
    {
        if (musicSource != null)
        {
            musicSource.Stop();
            musicSource.clip = null;
        }
        currentMusicId = null;
        musicEndTime = 0f;
    }

    private void UpdateMusicLifetime()
    {
        if (string.IsNullOrEmpty(currentMusicId) || musicSource == null) return;

        if (musicEndTime > 0f && Time.unscaledTime >= musicEndTime)
        {
            StopCurrentMusic();
            return;
        }

        // Clip không loop sẽ tự kết thúc; xóa trạng thái để có thể bật lại cùng ID.
        if (!musicSource.isPlaying)
        {
            currentMusicId = null;
            musicEndTime = 0f;
        }
    }

    // -------------------------------------------------------------------------
    // Internal SFX
    // -------------------------------------------------------------------------

    private void PlaySfxInternal(string sfxId)
    {
        if (!TryGetSfx(sfxId, out AudioConfig.SfxEntry entry) || entry.clip == null) return;

        AudioSource source = GetAvailableOneShotSource();
        ConfigureSfxSource(source, entry);
        oneShotBaseVolumes[source] = Mathf.Clamp01(entry.volume);
        source.loop = false;
        source.clip = entry.clip;
        source.Play();
    }

    private void PlaySfxLoopInternal(string sfxId, float durationSeconds)
    {
        if (!TryGetSfx(sfxId, out AudioConfig.SfxEntry entry) || entry.clip == null) return;

        if (!activeSfxLoops.TryGetValue(sfxId, out AudioSource source) || source == null)
        {
            source = CreateChildAudioSource("SFX Loop - " + sfxId);
            activeSfxLoops[sfxId] = source;
        }
        else
        {
            source.Stop();
        }

        ConfigureSfxSource(source, entry);
        source.loop = true;
        source.clip = entry.clip;
        source.Play();

        if (durationSeconds > 0f)
            sfxLoopEndTimes[sfxId] = Time.unscaledTime + durationSeconds;
        else
            sfxLoopEndTimes.Remove(sfxId);
    }

    private void StopSfxLoopInternal(string sfxId)
    {
        if (string.IsNullOrWhiteSpace(sfxId)) return;

        if (activeSfxLoops.TryGetValue(sfxId, out AudioSource source))
        {
            if (source != null)
            {
                source.Stop();
                Destroy(source.gameObject);
            }
            activeSfxLoops.Remove(sfxId);
        }

        sfxLoopEndTimes.Remove(sfxId);
    }

    private void UpdateSfxLoopLifetimes()
    {
        if (activeSfxLoops.Count == 0) return;

        expiredLoopIds.Clear();
        foreach (KeyValuePair<string, AudioSource> pair in activeSfxLoops)
        {
            string id = pair.Key;
            AudioSource source = pair.Value;

            bool timedOut = sfxLoopEndTimes.TryGetValue(id, out float endTime)
                            && Time.unscaledTime >= endTime;
            bool sourceEnded = source == null || !source.isPlaying;

            if (timedOut || sourceEnded)
                expiredLoopIds.Add(id);
        }

        for (int i = 0; i < expiredLoopIds.Count; i++)
            StopSfxLoopInternal(expiredLoopIds[i]);
    }

    private bool TryGetSfx(string id, out AudioConfig.SfxEntry entry)
    {
        if (audioConfig != null && audioConfig.TryGetSfx(id, out entry))
            return true;

        WarnMissingId(id, false);
        entry = null;
        return false;
    }

    private void WarnMissingId(string id, bool isMusic)
    {
        if (string.IsNullOrWhiteSpace(id)) return;
        HashSet<string> warnings = isMusic ? missingMusicWarnings : missingSfxWarnings;
        if (!warnings.Add(id)) return;

        Debug.LogWarning($"[VolumeManager] Không tìm thấy {(isMusic ? "Music" : "SFX")} ID '{id}' trong AudioConfig.", this);
    }

    // -------------------------------------------------------------------------
    // AudioSource pool and volume application
    // -------------------------------------------------------------------------

    private AudioSource GetAvailableOneShotSource()
    {
        for (int i = 0; i < oneShotPool.Count; i++)
        {
            AudioSource source = oneShotPool[i];
            if (source != null && !source.isPlaying)
                return source;
        }

        AudioSource newSource = CreateChildAudioSource("SFX One Shot " + oneShotPool.Count);
        oneShotPool.Add(newSource);
        return newSource;
    }

    private AudioSource CreateChildAudioSource(string objectName)
    {
        GameObject child = new GameObject(objectName);
        child.transform.SetParent(transform, false);

        AudioSource source = child.AddComponent<AudioSource>();
        source.playOnAwake = false;
        source.spatialBlend = 0f;
        source.loop = false;
        return source;
    }

    private void ConfigureSfxSource(AudioSource source, AudioConfig.SfxEntry entry)
    {
        source.volume = GetSfxChannelVolume() * Mathf.Clamp01(entry.volume);
        source.pitch = Mathf.Max(0.1f, entry.pitch);
        source.spatialBlend = 0f;
    }

    private float GetMusicChannelVolume() => musicMuted ? 0f : musicVolume;
    private float GetSfxChannelVolume() => sfxMuted ? 0f : sfxVolume;

    private static void ApplyLegacySources(HashSet<AudioSource> sources, float volume)
    {
        sources.RemoveWhere(source => source == null);
        foreach (AudioSource source in sources)
            source.volume = volume;
    }

    private void ApplyVolumes()
    {
        AudioListener.volume = masterMuted ? 0f : masterVolume;
        ApplyLegacySources(legacyMusicSources, GetMusicChannelVolume());
        ApplyLegacySources(legacySfxSources, GetSfxChannelVolume());

        if (musicSource != null && !string.IsNullOrEmpty(currentMusicId)
            && audioConfig != null
            && audioConfig.TryGetMusic(currentMusicId, out AudioConfig.MusicEntry musicEntry))
        {
            musicSource.volume = GetMusicChannelVolume() * Mathf.Clamp01(musicEntry.volume);
        }

        // Áp dụng lại volume cho các SFX đang phát, gồm cả one-shot và loop.
        for (int i = 0; i < oneShotPool.Count; i++)
        {
            AudioSource source = oneShotPool[i];
            if (source != null && source.isPlaying)
            {
                float baseVolume = oneShotBaseVolumes.TryGetValue(source, out float value) ? value : 1f;
                source.volume = GetSfxChannelVolume() * baseVolume;
            }
        }

        foreach (KeyValuePair<string, AudioSource> pair in activeSfxLoops)
        {
            if (pair.Value != null && audioConfig != null
                && audioConfig.TryGetSfx(pair.Key, out AudioConfig.SfxEntry entry))
            {
                pair.Value.volume = GetSfxChannelVolume() * Mathf.Clamp01(entry.volume);
            }
        }
    }

    // Lưu volume gốc theo AudioSource để thay đổi slider/mute không làm mất volume riêng từng SFX.
    private readonly Dictionary<AudioSource, float> oneShotBaseVolumes = new Dictionary<AudioSource, float>();
}
