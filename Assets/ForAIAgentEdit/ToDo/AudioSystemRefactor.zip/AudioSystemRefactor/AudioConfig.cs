using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Database âm thanh của game. Mọi âm thanh được gọi bằng ID đã đăng ký trong GameIdRegistry.
/// Đặt một asset AudioConfig trong project và gán vào VolumeManager.
/// </summary>
[CreateAssetMenu(fileName = "AudioConfig", menuName = "Bóng Ngủ/Audio Config")]
public sealed class AudioConfig : ScriptableObject
{
    [Serializable]
    public sealed class MusicEntry
    {
        [RegistryId(RegistryIdType.Music)]
        public string id;

        public AudioClip clip;

        [Range(0f, 1f)] public float volume = 1f;
        [Range(0.1f, 3f)] public float pitch = 1f;
        public bool loop = true;

        [Tooltip("Thời gian phát tối đa tính bằng giây. 0 = không tự dừng; nếu Loop tắt thì bài tự kết thúc theo độ dài clip.")]
        [Min(0f)] public float stopAfterSeconds;
    }

    [Serializable]
    public sealed class SfxEntry
    {
        [RegistryId(RegistryIdType.Sfx)]
        public string id;

        public AudioClip clip;

        [Range(0f, 1f)] public float volume = 1f;
        [Range(0.1f, 3f)] public float pitch = 1f;
    }

    [Header("Music")]
    [SerializeField] private List<MusicEntry> musics = new List<MusicEntry>();

    [Header("SFX")]
    [SerializeField] private List<SfxEntry> sfx = new List<SfxEntry>();

    [NonSerialized] private Dictionary<string, MusicEntry> musicLookup;
    [NonSerialized] private Dictionary<string, SfxEntry> sfxLookup;

    public IReadOnlyList<MusicEntry> Musics => musics;
    public IReadOnlyList<SfxEntry> Sfx => sfx;

    private void OnEnable() => RebuildLookup();
    private void OnValidate() => RebuildLookup();

    public void RebuildLookup()
    {
        musicLookup = new Dictionary<string, MusicEntry>(StringComparer.Ordinal);
        sfxLookup = new Dictionary<string, SfxEntry>(StringComparer.Ordinal);

        if (musics != null)
        {
            foreach (MusicEntry entry in musics)
            {
                if (entry == null || string.IsNullOrWhiteSpace(entry.id)) continue;
                if (musicLookup.ContainsKey(entry.id))
                {
                    Debug.LogWarning($"[AudioConfig] Music ID bị trùng: '{entry.id}'. Chỉ lấy dòng đầu tiên.", this);
                    continue;
                }
                musicLookup.Add(entry.id, entry);
            }
        }

        if (sfx != null)
        {
            foreach (SfxEntry entry in sfx)
            {
                if (entry == null || string.IsNullOrWhiteSpace(entry.id)) continue;
                if (sfxLookup.ContainsKey(entry.id))
                {
                    Debug.LogWarning($"[AudioConfig] SFX ID bị trùng: '{entry.id}'. Chỉ lấy dòng đầu tiên.", this);
                    continue;
                }
                sfxLookup.Add(entry.id, entry);
            }
        }
    }

    public bool TryGetMusic(string id, out MusicEntry entry)
    {
        EnsureLookup();
        if (!string.IsNullOrWhiteSpace(id) && musicLookup.TryGetValue(id, out entry))
            return true;

        entry = null;
        return false;
    }

    public bool TryGetSfx(string id, out SfxEntry entry)
    {
        EnsureLookup();
        if (!string.IsNullOrWhiteSpace(id) && sfxLookup.TryGetValue(id, out entry))
            return true;

        entry = null;
        return false;
    }

    private void EnsureLookup()
    {
        if (musicLookup == null || sfxLookup == null)
            RebuildLookup();
    }
}
