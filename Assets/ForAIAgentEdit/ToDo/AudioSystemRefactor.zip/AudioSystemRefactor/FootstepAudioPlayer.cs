using UnityEngine;

/// <summary>
/// Phát tiếng bước chân qua VolumeManager theo SFX ID.
/// Không cần AudioSource trên Player.
/// </summary>
public sealed class FootstepAudioPlayer : MonoBehaviour
{
    [SerializeField, RegistryId(RegistryIdType.Sfx)] private string footstepSfxId;
    [SerializeField, Min(0.05f)] private float interval = 0.32f;
    [SerializeField, Min(0f)] private float movementThreshold = 0.05f;

    private Rigidbody2D body;
    private float timer;

    private void Awake()
    {
        body = GetComponent<Rigidbody2D>();
    }

    public void SetSfxId(string sfxId)
    {
        if (!string.IsNullOrWhiteSpace(sfxId))
            footstepSfxId = sfxId;
    }

    private void Update()
    {
        if (GameplayPause.IsPaused || body == null || string.IsNullOrWhiteSpace(footstepSfxId)
            || !VolumeManager.IsReady || body.linearVelocity.sqrMagnitude < movementThreshold * movementThreshold)
        {
            timer = 0f;
            return;
        }

        timer += Time.deltaTime;
        if (timer < interval) return;

        timer = 0f;
        VolumeManager.PlaySFX(footstepSfxId);
    }
}
